package Adapter;

//Classe alvo (Target)
class SensorNitendo {

  //Solicita��o
  public void conectarNitendo() {
      System.out.println("Um novo controle foi conectado ao sensor do Nitendo.");
  }
}
