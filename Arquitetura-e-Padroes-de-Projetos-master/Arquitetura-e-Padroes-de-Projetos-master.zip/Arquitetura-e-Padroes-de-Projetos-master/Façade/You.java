package Fa�ade;

class You {
	  public static void main(String[] args) {
	    Computer facade = new Computer();
	    facade.startComputer();
	  }
	}