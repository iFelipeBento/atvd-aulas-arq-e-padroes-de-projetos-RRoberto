package Fa�ade;

class Memory {
	  public void load(long position, byte[] data) {  }
	}