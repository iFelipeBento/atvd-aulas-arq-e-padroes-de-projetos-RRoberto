package Fa�ade;

class HardDrive {
	  public byte[] read(long lba, int size) {
		return null;  }
	}
