# Arquitetura-e-Padroes-de-Projetos
