package AbstractFactory;

class ProdutoA1 implements ProdutoAbstratoA {

}