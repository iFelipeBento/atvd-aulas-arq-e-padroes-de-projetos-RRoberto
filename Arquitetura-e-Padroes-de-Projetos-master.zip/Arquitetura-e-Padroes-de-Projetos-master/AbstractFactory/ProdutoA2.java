package AbstractFactory;

class ProdutoA2 implements ProdutoAbstratoA {

}