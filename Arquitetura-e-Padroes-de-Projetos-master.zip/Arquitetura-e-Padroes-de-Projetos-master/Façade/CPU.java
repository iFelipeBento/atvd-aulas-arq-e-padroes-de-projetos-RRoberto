package Fa�ade;

class CPU {
	  public void freeze() {  }
	  public void jump(long position) {  }
	  public void execute() {  }
	}