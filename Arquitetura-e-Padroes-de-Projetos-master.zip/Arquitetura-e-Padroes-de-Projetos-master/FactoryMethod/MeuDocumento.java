package FactoryMethod;

/**
* Esta classe concreta cont�m a implementa��o
* de um tipo de documento espec�fico.
*/
  class MeuDocumento extends Documento {

  }
